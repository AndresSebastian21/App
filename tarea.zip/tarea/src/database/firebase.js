import firebase from 'firebase';
import 'firebase/firestore';

  var firebaseConfig = {
    apiKey: "AIzaSyBOZdDojQ9_lJNmEHer6laXzNQiJOw_AO4",
    authDomain: "videojuegos-6a3e2.firebaseapp.com",
    projectId: "videojuegos-6a3e2",
    storageBucket: "videojuegos-6a3e2.appspot.com",
    messagingSenderId: "580869006927",
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);

  const db = firebase.firestore();

  export default {
    firebase,
    db
  }