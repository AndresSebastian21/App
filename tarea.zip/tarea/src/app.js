import * as React from 'react';
import {NavigationContainer} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';
import {AuthStackNavigator} from './navigators/AuthStackNavigator';
import {AuthContext} from './contexts/AuthContext';
import firebase from './database/firebase';

const RootStack = createStackNavigator();

export default function () {
 const auth = React.useMemo( () => ({
      register: async(nombreJuego, tipo, consola, marca, precio) => {
      alert('Registrado: '+ nombreJuego +', '+ tipo + ', ' + consola + ', ' +   marca + ', ' + precio);
      await firebase.db.collection('users').add({
      nombreJuego: nombreJuego,
      tipo: tipo,
      consola: consola,
      marca: marca,
      precio: precio
    })
    },
  }),
    [],
  );

  return(
    <AuthContext.Provider value={auth}>
    <NavigationContainer>
      <RootStack.Navigator
      screenOptions={{
        headerShown: false,
      }}
      >
        <RootStack.Screen name={'AuthStack'} component={AuthStackNavigator}/>
      </RootStack.Navigator>
    </NavigationContainer>
    </AuthContext.Provider>
  );
}