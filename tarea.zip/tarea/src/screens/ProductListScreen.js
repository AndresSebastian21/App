import * as React from 'react';
import { useState, useEffect } from 'react';
import { Text, View, StyleSheet } from 'react-native';
import { LinearGradient } from "expo-linear-gradient"; 
import { Heading } from '../components/Heading';
import { TextButton } from '../components/TextButton';
import { IconButton } from '../components/IconButton';
import { ListItem, Avatar} from 'react-native-elements'; 
import { AuthContext } from '../contexts/AuthContext';

import firebase from '../database/firebase';

export function ProductListScreen({ navigation }) {
  const [users, setusers] = useState([]);

  useEffect(() => {
    firebase.db.collection('users').onSnapshot((querySnapshot) => {
      const productos = [];
      querySnapshot.docs.forEach((doc) => {
        //console.log(doc.data());
        const {consola, marca, nombreJuego, precio, tipo} = doc.data();
        productos.push({
          id: doc.id,
          consola, 
          marca, 
          nombreJuego, 
          precio, 
          tipo
        });
      });
      setusers(productos);
    })
  }, []);

  return (
    <View style={styles.container}>
   
      <IconButton
        name="arrow-back-circle-outline"
        size={36}
        color={'red'}
        style={styles.icon}
        onPress={() => {
          navigation.pop();
        }}
      />
      <Heading content="Lista de Videjuegos" style={{color: 'black', marginBottom: 20}} />
      {
        users.map(users =>{
          return(
            <ListItem 
              key={users.id}
              bottomDivider
              onPress = {()=> {
                navigation.navigate('ProductDetail', {
                  usersId: users.id
                });
              }}
              >
               
              <ListItem.Content>
                <ListItem.Title>{users.nombreJuego}</ListItem.Title>
                <ListItem.Subtitle>{users.consola}</ListItem.Subtitle>
                <ListItem.Subtitle>{users.tipo}</ListItem.Subtitle>
                <ListItem.Subtitle>{users.marca}</ListItem.Subtitle>
                <ListItem.Subtitle>{users.precio}</ListItem.Subtitle>
              </ListItem.Content>
            </ListItem>
          );
        })
      }
    
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 0,
  },
  linear: {
    flex: 1,
    justifyContent: 'center',
    padding: 0,
  },
  icon: {
    position: 'absolute',
    top: 30,
    right: 20,
  },
});