import * as React from 'react';
import { useEffect } from 'react';
import { Text, View, StyleSheet } from 'react-native';
import {Heading} from '../components/Heading'; 
import {Input} from '../components/Input';
import {Button} from '../components/Button';
import {TextButton} from '../components/TextButton';
import {IconButton} from '../components/IconButton';

import {AuthContext} from '../contexts/AuthContext';

import firebase from '../database/firebase';

export function ProductDetailScreen({route, navigation}) {

  const id = route.params.usersId;
  console.log(id);
  const [nombreJuego, setnombreJuego] = React.useState('');
  const [tipo, settipo] = React.useState('');
  const [consola, setconsola] = React.useState('');
  const [marca, setmarca] = React.useState('');
  const [precio, setPrecio] = React.useState('');

  const getusersById = async(id)=> {
    const dbRef = firebase.db.collection('users').doc(id);
    const doc = await dbRef.get();
    console.log(doc.data());

    const users = doc.data();
    setnombreJuego(users.nombreJuego);
    settipo(users.tipo);
    setconsola(users.consola);
    setmarca(users.marca);
    setPrecio(users.precio);
  }
  
  useEffect(()=>{
    getusersById(id);
  }, [])

  const deleteProduct = async(idProduct)=>{
    const dbRef = firebase.db.collection('users').doc(idProduct);
    await dbRef.delete();
    alert('Producto eliminado')
    navigation.navigate('ProductList');
  }

  const updateProduct = async(idProduct)=>{
    const dbRef = firebase.db.collection('users').doc(idProduct);
    await dbRef.set({
      nombreJuego: nombreJuego,
      tipo: tipo,
      consola: consola,
      marca: marca,
      precio: precio
    });
    alert('Datos actualizados')
    navigation.navigate('ProductList');
  }

  return (
    <View style={styles.container}>
    <IconButton 
    name="arrow-back-circle-outline" 
    size={36} 
    color={'red'} 
    style={styles.icon} 
    onPress= {() => { navigation.pop();
    }} 
    />
    <Heading 
    content='Detalles'
    style={styles.heading}
    />
    <Input 
    style={styles.input} 
    placeholder={'Nombre'} 
    value={nombreJuego}
    onChangeText = {setnombreJuego}
    />
    <Input 
    style={styles.input} 
    placeholder={'Tipo'} 
    value={tipo}
    onChangeText = {settipo}
    />
    <Input 
    style={styles.input} 
    placeholder={'Consola'} 
    value={consola}
    onChangeText = {setconsola}
    />
    <Input 
    style={styles.input} 
    placeholder={'Marca'} 
    value={marca}
    onChangeText = {setmarca}
    />
    <Input 
    style={styles.input} 
    placeholder={'Precio'} 
    value={precio}
    onChangeText = {setPrecio}
    />
    <Button 
    text='Actualizar'
    style={styles.button}
    onPress={()=>{
      updateProduct(id);
    }}
    />
    <Button 
    text='Eliminar'
     style={styles.button}
    onPress={()=>{
      deleteProduct(id);
    }}
    />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    flex: 1,
    justifyContent: 'center',
    padding: 0,
  },
  button:{
    marginVertical: 20
  },
  heading:{
    marginBottom: 20
  },
  icon:{
    position: 'absolute',
    top: 30,
    right: 20,
  }
  
});