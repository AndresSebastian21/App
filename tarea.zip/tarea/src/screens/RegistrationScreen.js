import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import {Heading} from '../components/Heading'; 
import {Input} from '../components/Input';
import {Button} from '../components/Button';
import {TextButton} from '../components/TextButton';
import {IconButton} from '../components/IconButton';

import {AuthContext} from '../contexts/AuthContext';

export function RegistrationScreen({navigation}) {

  const { register } = React.useContext (AuthContext);
  const [nombreJuego, setnombreJuego] = React.useState('');
  const [tipo, settipo] = React.useState('');
  const [consola, setconsola] = React.useState('');
  const [marca, setmarca] = React.useState('');
  const [precio, setPrecio] = React.useState('');

  return (
    <View style={styles.container}>
    <IconButton 
    name="arrow-back-circle-outline" 
    size={36} 
    color={'red'} 
    style={styles.icon} 
    onPress= {() => { navigation.pop();
    }} 
    />
    <Heading 
    content='Nuevo registro'
    style={styles.heading}
    />
     <Input 
    style={styles.input} 
    placeholder={'Nombre'} 
    value={nombreJuego}
    onChangeText = {setnombreJuego}
    />
    <Input 
    style={styles.input} 
    placeholder={'Tipo'} 
    value={tipo}
    onChangeText = {settipo}
    />
    <Input 
    style={styles.input} 
    placeholder={'Consola'} 
    value={consola}
    onChangeText = {setconsola}
    />
    <Input 
    style={styles.input} 
    placeholder={'Marca'} 
    value={marca}
    onChangeText = {setmarca}
    />
    <Input 
    style={styles.input} 
    placeholder={'Precio'} 
    value={precio}
    onChangeText = {setPrecio}
    />
    <Button text='Crear producto' style={styles.button} onPress={() => {
        register(nombreJuego, tipo, consola, marca, precio);
      }}  /> 
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    padding: 0,
  },
  input:{
    marginVertical: 10
  },
  button:{
    marginVertical: 20
  },
  heading:{
    marginBottom: 20
  },
  icon:{
    position: 'absolute',
    top: 30,
    right: 20,
  }
  
});