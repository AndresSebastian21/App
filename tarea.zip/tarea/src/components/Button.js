import * as React from 'react';
import { StyleSheet, TouchableOpacity, Text } from 'react-native';

export function Button({style, text, onPress}) {
  return (
    <TouchableOpacity style={[style, styles.button]} onPress={onPress}>
    <Text style={styles.text} >{text.toUpperCase()}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  button: {
    backgroundColor: 'pink',
    width: '90%',
    padding: 8,
    borderRadius: 10,
    marginBottom:10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  text:{
    color: 'black',
    textAlign: 'center',
    fontSize: 15,
    fontWeight: "bold"
  }
  
});