import * as React from 'react';
import App from './src/app';

export default function(){
  return <App />
}

